The lcyfonts.fdd and ot2fonts.fdd files create font definitions of
LCY  and  OT2  encodings for lh-based fonts.  Since there could be
overlapping with  lcycmlh.fdd  and ot2cmlh.fdd files from cyrillic
bundle of packages installation of fd-files commented.

There are also created  style files for printing with standard and
extended  set  of Concrete fonts  (with  Concrete Roman  bold face 
fonts).

The t2ccfonts.fdd installs style file for  usage of Concrete Roman
fonts in standard  and extended set (with Concrete Roman bold face
fonts).

File nfssfox.dtx  installs extension of  nfssfont.tex/textfont.tex
files. (Plain TeX analog  testfox.tex  exists in the tex/plain/lh/
subdir.)