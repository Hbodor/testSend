% Ascii 7 bits file
% File enhyphex.tex
% English hyphenation exception words.
\message{Enhyphex.tex English exception words.}
\hyphenation{ % Do NOT make any alterations to this list! --- DEK
as-so-ciate
as-so-ciates
dec-li-na-tion
oblig-a-tory
phil-an-thropic
present
presents
project
projects
reci-procity
re-cog-ni-zance
ref-or-ma-tion
ret-ri-bu-tion
ta-ble
}

% additional exceptions (mjf)
\hyphenation{
man-u-script
man-u-scripts
equi-sp-a-ced
}
